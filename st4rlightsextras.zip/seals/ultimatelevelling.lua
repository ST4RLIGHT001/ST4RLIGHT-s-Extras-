
SMODS.Seal {
    key = 'ultimatelevelling',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            repetitions = 1000
        }
    },
    badge_colour = HEX('FFB347'),
    loc_txt = {
        name = 'Ultimate Levelling',
        label = 'Ultimate Levelling',
        text = {
            [1] = 'Creates {E:2,C:attention}1000{} {E:2,C:enhanced}Negative{} {E:2,C:planet}Planet{} cards for {C:dark_edition,E:1}poker hand{} played',
            [2] = '{C:inactive}(Note from developer: please only use this on 1 card){}'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            for i = 1, 1000 do
                G.E_MANAGER:add_event(Event({
                    trigger = 'before',
                    delay = 0.0,
                    func = function()
                        if G.GAME.last_hand_played then
                            local _planet = nil
                            for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                                if v.config.hand_type == G.GAME.last_hand_played then
                                    _planet = v.key
                                end
                            end
                            if _planet then
                                local planet_card = SMODS.add_card({ key = _planet })
                                planet_card:set_edition("e_negative", true)
                            end
                            
                        end
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_planet'), colour = G.C.SECONDARY_SET.Planet})
            end
        end
    end
}