
SMODS.Voucher {
    key = 'prime_ultimatum',
    pos = { x = 0, y = 0 },
    config = { 
        extra = {
            hands0 = 100,
            discards0 = 100,
            hand_size0 = 142,
            play_size0 = 142,
            discard_size0 = 142,
            booster_slots0 = 4,
            repetitions = 20
        } 
    },
    loc_txt = {
        name = 'Prime Ultimatum',
        text = {
            [1] = '{C:enhanced}Are you ready for the power of this voucher?{}'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 6,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.GAME.round_resets.hands = 100
        ease_hands_played(100 - G.GAME.current_round.hands_left)
        G.GAME.round_resets.discards = 100
        ease_discard(100 - G.GAME.current_round.discards_left)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(142)
                    return true
                end
            })),
            extra = {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        SMODS.change_play_limit(142)
                        return true
                    end
                })),
                colour = G.C.WHITE,
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            SMODS.change_discard_limit(142)
                            return true
                        end
                    })),
                    colour = G.C.WHITE,
                    extra = {
                        
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.jokers.config.card_limit = G.jokers.config.card_limit + 100
                                return true
                            end
                        }))
                        ,
                        colour = G.C.DARK_EDITION,
                        extra = {
                            
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    G.consumeables.config.card_limit = G.consumeables.config.card_limit + 100
                                    return true
                                end
                            }))
                            ,
                            colour = G.C.BLUE,
                            extra = {
                                
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        G.GAME.modifiers.booster_choice_mod = (G.GAME.modifiers.booster_choice_mod or 0) +7
                                        return true
                                    end
                                }))
                                ,
                                colour = G.C.BLUE,
                                extra = {
                                    
                                    G.E_MANAGER:add_event(Event({
                                        func = function()
                                            
                                            
                                            SMODS.change_booster_limit(4)
                                            return true
                                        end
                                    })),
                                    colour = G.C.WHITE,
                                    extra = {
                                        
                                        G.E_MANAGER:add_event(Event({
                                            func = function()
                                                G.GAME.interest_cap = G.GAME.interest_cap +1.0000000000000003e+21
                                                return true
                                            end
                                        }))
                                        ,
                                        colour = G.C.BLUE
                                    }
                                }
                            }
                        }
                    }
                }
            }
            ,
            func = function()
                for i = 1, 20 do
                    SMODS.calculate_effect({func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local tag = Tag("tag_rare")
                                if tag.name == "Orbital Tag" then
                                    local _poker_hands = {}
                                    for k, v in pairs(G.GAME.hands) do
                                        if v.visible then
                                            _poker_hands[#_poker_hands + 1] = k
                                        end
                                    end
                                    tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                end
                                tag:set_ability()
                                add_tag(tag)
                                play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                return true
                            end
                        }))
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
                    SMODS.calculate_effect({func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local tag = Tag("tag_negative")
                                if tag.name == "Orbital Tag" then
                                    local _poker_hands = {}
                                    for k, v in pairs(G.GAME.hands) do
                                        if v.visible then
                                            _poker_hands[#_poker_hands + 1] = k
                                        end
                                    end
                                    tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                end
                                tag:set_ability()
                                add_tag(tag)
                                play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                return true
                            end
                        }))
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
                end
                return true
            end
        }
    end
}