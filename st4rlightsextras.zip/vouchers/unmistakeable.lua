
SMODS.Voucher {
    key = 'unmistakeable',
    pos = { x = 2, y = 0 },
    loc_txt = {
        name = 'Unmistakeable',
        text = {
            [1] = 'Sets {C:attention}Ante{} to {C:attention}-10{}',
            [2] = '{C:inactive}Why? Do you just want to shop more? Then that\'s fine.{}'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 5,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    
}