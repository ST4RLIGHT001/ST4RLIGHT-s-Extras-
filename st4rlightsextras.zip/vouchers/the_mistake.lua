
SMODS.Voucher {
    key = 'the_mistake',
    pos = { x = 1, y = 0 },
    config = { 
        extra = {
            ante_value0 = 39,
            winner_ante_value0 = 39
        } 
    },
    loc_txt = {
        name = 'The Mistake',
        text = {
            [1] = '{E:2,C:enhanced}The end of your run? (Endless Mode usage){}'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 1,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_unmistakeable'},
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        local mod = 39 - G.GAME.round_resets.ante
        ease_ante(mod)
        G.GAME.round_resets.blind_ante = 39
        return {
            func = function()
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.win_ante = 39
                        return true
                    end
                }))
                return true
            end,
            message = "Winner Ante set to " .. 39 .. "!"
        }
    end
}