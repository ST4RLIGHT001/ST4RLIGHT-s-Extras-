
SMODS.Enhancement {
    key = 'primetime',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            repetitions = 25,
            repetitions2 = 5
        }
    },
    loc_txt = {
        name = 'Prime Time',
        text = {
            [1] = '{C:attention,E:2}Spawns 25{} {C:rare,E:2}Rare{} and {C:attention,E:2}5{} {C:legendary,E:2}Legendary{} Jokers, all of them being {C:enhanced,E:2}Negative{}',
            [2] = '{C:gold}IT\'S PRIMING TIME!!!!!{} {C:inactive}(Must be held in hand to activate){}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            for i = 1, 25 do
                local created_joker = false
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    created_joker = true
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Rare' })
                            if joker_card then
                                joker_card:set_edition("e_negative", true)
                                
                            end
                            G.GAME.joker_buffer = 0
                            return true
                        end
                    }))
                end
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
            end
            for i = 1, 5 do
                local created_joker = false
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    created_joker = true
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Legendary' })
                            if joker_card then
                                joker_card:set_edition("e_negative", true)
                                
                            end
                            G.GAME.joker_buffer = 0
                            return true
                        end
                    }))
                end
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
            end
        end
    end
}