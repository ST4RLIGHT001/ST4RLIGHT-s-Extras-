
SMODS.Consumable {
    key = 'thebiaseddisablementsoul',
    set = 'Spectral',
    pos = { x = 0, y = 0 },
    config = { 
        extra = {
            repetitions = 10   
        } 
    },
    loc_txt = {
        name = 'The Biased Disablement Soul',
        text = {
            [1] = 'Creates {E:2}{C:attention}25{} {C:enhanced}Negative{} {C:spectral}Legendary{} {C:hearts,T:j_chicot} Chicot{} Jokers{}',
            [2] = '{C:inactive} (Doesn\'t need room...?){}'
        }
    },
    cost = 4,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        for i = 1, 10 do
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                        local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_chicot' })
                        if new_joker then
                            new_joker:set_edition("e_negative", true)
                        end
                        G.GAME.joker_buffer = 0
                    end
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            delay(0.6)
            
        end
    end,
    can_use = function(self, card)
        return true
    end
}