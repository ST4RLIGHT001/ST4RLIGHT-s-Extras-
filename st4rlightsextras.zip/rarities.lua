SMODS.Rarity {
    key = "ultimate",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.214,
    badge_colour = HEX('4e4ae2'),
    loc_txt = {
        name = "Ultimate"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}