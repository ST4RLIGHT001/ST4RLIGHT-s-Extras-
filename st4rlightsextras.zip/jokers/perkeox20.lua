
SMODS.Joker{ --Perkeo x20
    key = "perkeox20",
    config = {
        extra = {
            repetitions = 20
        }
    },
    loc_txt = {
        ['name'] = 'Perkeo x20',
        ['text'] = {
            [1] = '{E:2}Creates a {C:spectral,E:2}Negative{} copy of {C:attention}20{} random {C:attention}consumable{} cards',
            [2] = 'in your possession at the end of the {C:attention}shop{}',
            [3] = '{C:attention}(WARNING: USE OVERFLOW MOD OR YOUR GAME MAY CRASH!!!!!!!){}{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "xtras_ultimate",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 3,
        y = 0
    },
    
    set_ability = function(self, card, initial)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.ending_shop  then
            if true then
                for i = 1, 20 do
                    SMODS.calculate_effect({func = function()
                        local target_cards = {}
                        for i, consumable in ipairs(G.consumeables.cards) do
                            table.insert(target_cards, consumable)
                        end
                        if #target_cards > 0  then
                            local card_to_copy = pseudorandom_element(target_cards, pseudoseed('copy_consumable'))
                            
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local copied_card = copy_card(card_to_copy)
                                    copied_card:set_edition("e_negative", true)
                                    copied_card:add_to_deck()
                                    G.consumeables:emplace(copied_card)
                                    
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Copied Consumable!", colour = G.C.GREEN})
                        end
                        return true
                    end}, card)
                end
            end
        end
    end
}