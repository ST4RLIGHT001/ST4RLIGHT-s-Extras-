
SMODS.Joker{ --Ultimate Boosting (for endgame naneinf)
    key = "ultimateboostingforendgamenaneinf",
    config = {
        extra = {
            naneinf = 1e+308
        }
    },
    loc_txt = {
        ['name'] = 'Ultimate Boosting (for endgame naneinf)',
        ['text'] = {
            [1] = '{E:2}Multiplies {C:red}Mult{} by {X:mult,C:white}x1e308{} per {C:blue}card{} held in hand {X:attention,C:white}after{} hand played',
            [2] = '{C:attention}(NOTE: naneinf IS SUPER HIGH WITH TALISMAN AND CRYPTID SO THIS WILL BE SUPER POWERFUL. IF YOU DO NOT WANT naneinf OR AN UNBALANCED RUN, DO NOT TAKE THIS.){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "xtras_ultimate",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["xtras_extras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.naneinf}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            return {
                Xmult = card.ability.extra.naneinf
            }
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_xtras_ultimateboostingforendgamenaneinf" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_xtras_ultimateboostingforendgamenaneinf" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end