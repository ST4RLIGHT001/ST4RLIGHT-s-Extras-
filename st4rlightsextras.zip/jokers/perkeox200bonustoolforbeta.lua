
SMODS.Joker{ --Perkeo x200 (BONUS TOOL FOR BETA)
    key = "perkeox200bonustoolforbeta",
    config = {
        extra = {
            repetitions = 200
        }
    },
    loc_txt = {
        ['name'] = 'Perkeo x200 (BONUS TOOL FOR BETA)',
        ['text'] = {
            [1] = '{E:2}Creates a {C:spectral,E:2}Negative{} copy of {C:attention}200{} random {C:attention}consumable{} cards',
            [2] = 'in your possession at the end of the {C:attention}shop{}',
            [3] = '{C:attention}(WARNING: USE OVERFLOW MOD OR YOUR GAME MAY CRASH!!!!!!!){}',
            [4] = '{C:attention}(BETA TESTING TOOL MIGHT CAUSE CRASHES BUT MOST LIKELY WON\'T IF YOU USE OVERFLOW MOD.){}{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 6,
        y = 0
    },
    
    calculate = function(self, card, context)
        if context.ending_shop  then
            if true then
                for i = 1, 200 do
                    SMODS.calculate_effect({func = function()
                        local target_cards = {}
                        for i, consumable in ipairs(G.consumeables.cards) do
                            table.insert(target_cards, consumable)
                        end
                        if #target_cards > 0  then
                            local card_to_copy = pseudorandom_element(target_cards, pseudoseed('copy_consumable'))
                            
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local copied_card = copy_card(card_to_copy)
                                    copied_card:set_edition("e_negative", true)
                                    copied_card:add_to_deck()
                                    G.consumeables:emplace(copied_card)
                                    
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Copied Consumable!", colour = G.C.GREEN})
                        end
                        return true
                    end}, card)
                end
            end
        end
    end
}