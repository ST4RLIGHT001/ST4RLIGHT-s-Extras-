
SMODS.Joker{ --Chicot x69
    key = "chicotx69",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Chicot x69',
        ['text'] = {
            [1] = 'Disables effect of every {C:attention}Boss Blind{} {X:attention,C:white}x69{} {C:attention}times{}',
            [2] = '{C:red,E:2}THE BOSS BLINDS HATE THIS ONE TRICK!{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "extras_ultimate",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    set_ability = function(self, card, initial)
        card:set_edition("e_negative", true)
    end
}