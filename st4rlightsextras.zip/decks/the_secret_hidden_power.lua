
SMODS.Back {
    key = 'the_secret_hidden_power',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            hand_size0 = 104,
            play_size0 = 52,
            discard_size0 = 52,
            repetitions = 4
        },
    },
    loc_txt = {
        name = 'The Secret Hidden Power',
        text = {
            [1] = '{C:inactive}...{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_cry_speculo' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                end
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_cry_effarcire' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                end
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_cry_redeo' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                end
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_cry_crustulum' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                end
                return true
            end
        }))
        G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots + 25
        G.GAME.starting_params.consumable_slots = G.GAME.starting_params.consumable_slots + 25
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(104)
                    return true
                end
            })),
            extra = {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        SMODS.change_play_limit(52)
                        return true
                    end
                })),
                colour = G.C.WHITE,
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            SMODS.change_discard_limit(52)
                            return true
                        end
                    })),
                    colour = G.C.WHITE
                }
            }
            ,
            func = function()
                for i = 1, 4 do
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound('timpani')
                            local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_cry_tenebris' })
                            if new_joker then
                                new_joker:set_edition("e_negative", true)
                            end
                            return true
                        end
                    }))
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound('timpani')
                            local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_cry_energia' })
                            if new_joker then
                                new_joker:set_edition("e_negative", true)
                            end
                            return true
                        end
                    }))
                    
                end
                return true
            end
        }
    end
}