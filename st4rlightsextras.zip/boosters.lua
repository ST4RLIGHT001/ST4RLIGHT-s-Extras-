
SMODS.Booster {
    key = 'ultimate_pack2',
    loc_txt = {
        name = "Ultimate Pack",
        text = {
            [1] = '{E:2}Choose {C:attention}2 out of 4{} {C:purple}Ultimate{} {C:red}Joker{} cards{}'
        },
        group_name = "extras_boosters"
    },
    config = { extra = 4, choose = 2 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "extras_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('extras_ultimate_pack2_card', 1, 2)
        if selected_index == 1 then
            return {
                key = "j_chicotx69",
                set = "Joker",
                edition = "e_negative",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "extras_ultimate_pack2"
            }
        elseif selected_index == 2 then
            return {
                key = "j_perkeox20",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "extras_ultimate_pack2"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    